CREATE DATABASE dammines;
USE dammines;

-- 1. Tabla de Usuarios
CREATE TABLE usuario (
  id_usuario INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL,
  fecha_ini TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
);

-- 2. Tabla de Partidas
CREATE TABLE partida (
  id_partida INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  inicio TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  id_usuario INT(11) NOT NULL,
  dificultad VARCHAR(10) NOT NULL DEFAULT 'Facil',
  resultado VARCHAR(10) DEFAULT 'En curso',
  CONSTRAINT partida_ibfk_1 FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario) ON DELETE CASCADE
);

-- 3. Tabla Padre de Celdas 
CREATE TABLE celda (
  id_partida INT(11) NOT NULL,
  fila INT(11) NOT NULL,
  columna INT(11) NOT NULL,
  estado_visibilidad VARCHAR(20) DEFAULT 'Tapada',
  PRIMARY KEY (id_partida, fila, columna),
  CONSTRAINT celda_ibfk_1 FOREIGN KEY (id_partida) REFERENCES partida (id_partida) ON DELETE CASCADE
);

-- 4. Tablas Hijas (Hijas de Celda)
CREATE TABLE mina (
  id_partida INT(11) NOT NULL,
  fila INT(11) NOT NULL,
  columna INT(11) NOT NULL,
  PRIMARY KEY (id_partida, fila, columna),
  CONSTRAINT mina_ibfk_1 FOREIGN KEY (id_partida, fila, columna) REFERENCES celda (id_partida, fila, columna) ON DELETE CASCADE
);

CREATE TABLE numero (
  id_partida INT(11) NOT NULL,
  fila INT(11) NOT NULL,
  columna INT(11) NOT NULL,
  numero INT(11) NOT NULL,
  PRIMARY KEY (id_partida, fila, columna),
  CONSTRAINT numero_ibfk_1 FOREIGN KEY (id_partida, fila, columna) REFERENCES celda (id_partida, fila, columna) ON DELETE CASCADE
);

CREATE TABLE vacio (
  id_partida INT(11) NOT NULL,
  fila INT(11) NOT NULL,
  columna INT(11) NOT NULL,
  PRIMARY KEY (id_partida, fila, columna),
  CONSTRAINT vacio_ibfk_1 FOREIGN KEY (id_partida, fila, columna) REFERENCES celda (id_partida, fila, columna) ON DELETE CASCADE
);